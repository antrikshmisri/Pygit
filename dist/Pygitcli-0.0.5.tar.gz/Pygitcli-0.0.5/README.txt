Pygitcli is a module that allows to use git terminal commands from a python file/script.
